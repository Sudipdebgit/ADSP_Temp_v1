# Semi-Supervised BSS for Speech-Noise Separation

Complete pipeline for training a semi-supervised blind source separation (BSS) model to separate speech from noise using STFT magnitude spectrograms.

## Overview

This project implements:
- **U-Net based architecture** for source separation
- **Semi-supervised learning** (supports both labeled and unlabeled data)
- **STFT-based processing** with magnitude and phase
- **Comprehensive evaluation** with SIR, SAR, SDR metrics
- **Audio reconstruction** for listening to separated sources

## Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Prepare Data

Create a `noise_pool/` directory and add your noise samples (`.wav` files):

```
noise_pool/
├── noise_001.wav
├── noise_002.wav
└── ...
```

## Quick Start

### Option 1: Run Complete Pipeline (Recommended)

```bash
chmod +x run_pipeline.sh
./run_pipeline.sh
```

This will:
1. Download LibriSpeech speech data (if needed)
2. Generate mixed dataset (speech + noise)
3. Convert to STFT format
4. Split into train/validation sets
5. Train the model
6. Evaluate with BSS metrics
7. Generate audio outputs

### Option 2: Run Steps Individually

#### Step 0: Split Dataset

```bash
python split_dataset.py \
    --meta_path dataset_stft/meta.jsonl \
    --output_dir dataset_stft \
    --train_ratio 0.8
```

#### Step 1: Create Dataset Module

The dataset module (`bss_dataset.py`) is used by training scripts. Test it:

```bash
python bss_dataset.py
```

#### Step 2: Create Model

The model module (`bss_model.py`) defines the U-Net architecture. Test it:

```bash
python bss_model.py
```

#### Step 3: Train Model

```bash
# Fully supervised (100% labeled data)
python bss_train.py \
    --train_meta dataset_stft/train_meta.jsonl \
    --val_meta dataset_stft/val_meta.jsonl \
    --output_dir checkpoints \
    --supervised_ratio 1.0 \
    --batch_size 16 \
    --num_epochs 50

# Semi-supervised (50% labeled data)
python bss_train.py \
    --train_meta dataset_stft/train_meta.jsonl \
    --val_meta dataset_stft/val_meta.jsonl \
    --output_dir checkpoints \
    --supervised_ratio 0.5 \
    --batch_size 16 \
    --num_epochs 50
```

**Monitor Training:**
```bash
tensorboard --logdir checkpoints/logs
```

#### Step 4: Evaluate Model

```bash
python bss_evaluate.py \
    --checkpoint checkpoints/best_model.pth \
    --meta_path dataset_stft/val_meta.jsonl \
    --output evaluation_results.json \
    --n_samples 100
```

This computes:
- **SDR** (Signal-to-Distortion Ratio): Overall quality
- **SIR** (Signal-to-Interference Ratio): Separation quality
- **SAR** (Signal-to-Artifacts Ratio): Artifact level
- **Processing time**: Inference speed

#### Step 5: Generate Audio Outputs

```bash
# Process dataset samples
python bss_inference.py \
    --checkpoint checkpoints/best_model.pth \
    --meta_path dataset_stft/val_meta.jsonl \
    --output_dir inference_outputs \
    --n_samples 10

# Separate custom audio file
python bss_inference.py \
    --checkpoint checkpoints/best_model.pth \
    --custom_audio path/to/your/audio.wav \
    --output_dir my_separation
```

## Output Structure

```
checkpoints/
├── best_model.pth          # Best model weights
├── checkpoint_epoch_5.pth  # Periodic checkpoints
└── logs/                   # TensorBoard logs

evaluation_results.json     # BSS metrics (SDR, SIR, SAR)

inference_outputs/
├── mix/                    # Original mixtures
├── s1_predicted/           # Predicted speech
├── s2_predicted/           # Predicted noise
├── s1_true/                # Ground truth speech
├── s2_true/                # Ground truth noise
└── inference_results.json  # Processing metadata
```

## Understanding the Results

### BSS Metrics

- **SDR (Signal-to-Distortion Ratio)**: Higher is better (typically 5-15 dB)
  - Measures overall separation quality
  
- **SIR (Signal-to-Interference Ratio)**: Higher is better (typically 10-20 dB)
  - Measures how much of the other source remains
  
- **SAR (Signal-to-Artifacts Ratio)**: Higher is better (typically 5-15 dB)
  - Measures artifacts introduced by separation

### Processing Time

- Typical inference time: 10-50 ms per 4-second audio clip
- Depends on GPU/CPU and model size

## Listening to Results

After running inference, you can compare:

1. **Original mix** (`mix/mix_XXXXX.wav`) - Speech + Noise
2. **Predicted speech** (`s1_predicted/s1_pred_XXXXX.wav`) - Model output
3. **True speech** (`s1_true/s1_true_XXXXX.wav`) - Ground truth
4. **Predicted noise** (`s2_predicted/s2_pred_XXXXX.wav`) - Separated noise
5. **True noise** (`s2_true/s2_true_XXXXX.wav`) - Ground truth noise

Use any audio player to listen and compare quality.

## Semi-Supervised Learning

The model supports semi-supervised learning where only a fraction of the training data has labels:

```bash
# 50% labeled data
python bss_train.py --supervised_ratio 0.5 ...

# 10% labeled data (challenging)
python bss_train.py --supervised_ratio 0.1 ...
```

The model uses:
- **Supervised loss** on labeled samples (MSE on magnitude spectrograms)
- **Unsupervised loss** on all samples (reconstruction consistency)

## Customization

### Modify STFT Parameters

```bash
# Shorter FFT (faster, less frequency resolution)
python convert_to_stft.py --n_fft 256 --hop_length 64

# Longer FFT (slower, more frequency resolution)
python convert_to_stft.py --n_fft 1024 --hop_length 256
```

### Modify Model Size

Edit `bss_model.py` and change channel counts in `UNetBSS.__init__()`:

```python
# Smaller model (faster)
self.enc1 = self._conv_block(n_channels, 16)
self.enc2 = self._conv_block(16, 32)
...

# Larger model (better quality)
self.enc1 = self._conv_block(n_channels, 64)
self.enc2 = self._conv_block(64, 128)
...
```

## Troubleshooting

### Out of Memory

```bash
# Reduce batch size
python bss_train.py --batch_size 8 ...

# Use CPU
export CUDA_VISIBLE_DEVICES=""
```

### Poor Separation Quality

- Increase training epochs
- Use more training data
- Adjust supervised_ratio
- Tune lambda_unsup parameter
- Try different STFT parameters

### Slow Training

- Reduce num_workers if CPU bottleneck
- Use GPU if available
- Reduce model size
- Use mixed precision training (add to code)

## File Organization

```
split_dataset.py        # Split data into train/val
bss_dataset.py          # PyTorch Dataset class
bss_model.py            # U-Net model architecture
bss_train.py            # Training script
bss_evaluate.py         # Evaluation with BSS metrics
bss_inference.py        # Audio separation and reconstruction
convert_to_stft.py      # Convert audio to STFT
generate_dataset.py     # Generate speech+noise mixtures
requirements.txt        # Python dependencies
run_pipeline.sh         # Complete pipeline automation
```

## Citation

If you use this code, please cite:
- PyRoomAcoustics for room simulation
- mir_eval for BSS metrics
- LibriSpeech for speech data

## License

MIT License
